from django.apps import AppConfig


class Books_ManagementConfig(AppConfig):
    name = 'books_management'
